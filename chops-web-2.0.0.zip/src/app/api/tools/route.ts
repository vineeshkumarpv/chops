import { NextResponse } from 'next/server';
import { getScanner } from '@/lib/scanner';
import { ToolSourceInfo, getGlobalPaths, ToolSource } from '@/lib/types';
import * as os from 'os';
import * as path from 'path';

// GET /api/tools - Get all tools with their installed status
export async function GET() {
  try {
    const scanner = getScanner();
    const tools = scanner.getInstalledTools();
    
    const homeDir = os.homedir();
    const configHome = process.env.XDG_CONFIG_HOME || path.join(homeDir, '.config');
    
    return NextResponse.json(tools.map(t => ({
      tool: t.tool,
      displayName: t.info.displayName,
      color: t.info.color,
      icon: t.info.iconName,
      installed: t.installed,
      paths: getGlobalPaths(t.tool as ToolSource, homeDir, configHome)
    })));
  } catch (error) {
    console.error('Error fetching tools:', error);
    return NextResponse.json({ error: 'Failed to fetch tools' }, { status: 500 });
  }
}
