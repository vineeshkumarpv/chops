import { NextResponse } from 'next/server';
import { getScanner } from '@/lib/scanner';
import { db } from '@/lib/db';

// POST /api/scan - Trigger a filesystem scan
export async function POST() {
  try {
    const scanner = getScanner();
    
    // Scan all skills
    const skills = scanner.scanAll();
    
    // Get all existing skills
    const existingSkills = await db.skill.findMany();
    const existingByPath = new Map(existingSkills.map(s => [s.resolvedPath, s]));
    
    // Group by resolved path
    const grouped = new Map<string, typeof skills>();
    for (const skill of skills) {
      const existing = grouped.get(skill.resolvedPath) || [];
      existing.push(skill);
      grouped.set(skill.resolvedPath, existing);
    }
    
    // Upsert skills
    let newCount = 0;
    for (const [resolvedPath, installations] of grouped) {
      const primary = installations[0];
      const installedPaths = [...new Set(installations.map(i => i.filePath))];
      const toolSources = [...new Set(installations.map(i => i.toolSource))];
      
      const data = {
        resolvedPath,
        filePath: primary.filePath,
        isDirectory: primary.isDirectory,
        name: primary.name,
        description: primary.description,
        content: primary.content,
        frontmatter: JSON.stringify(primary.frontmatter),
        toolSources: toolSources.join(','),
        installedPaths: JSON.stringify(installedPaths),
        isGlobal: primary.isGlobal,
        projectName: primary.projectName,
        fileModifiedDate: primary.modDate,
        fileSize: primary.fileSize
      };
      
      if (existingByPath.has(resolvedPath)) {
        await db.skill.update({
          where: { resolvedPath },
          data
        });
      } else {
        await db.skill.create({ data });
        newCount++;
      }
    }
    
    // Remove skills that no longer exist
    const scannedPaths = new Set(grouped.keys());
    for (const skill of existingSkills) {
      if (!scannedPaths.has(skill.resolvedPath)) {
        await db.skill.delete({ where: { id: skill.id } });
      }
    }
    
    return NextResponse.json({ 
      success: true, 
      message: `Scanned $HOME and found ${skills.length} skills`,
      newSkills: newCount,
      total: skills.length
    });
  } catch (error) {
    console.error('Error scanning:', error);
    return NextResponse.json({ error: 'Failed to scan filesystem' }, { status: 500 });
  }
}
