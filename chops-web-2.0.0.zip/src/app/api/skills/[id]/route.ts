import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import * as fs from 'fs';
import * as path from 'path';
import { serializeSkillContent } from '@/lib/parser';

interface Params {
  params: Promise<{ id: string }>;
}

// GET /api/skills/[id] - Get a single skill
export async function GET(request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    
    const skill = await db.skill.findUnique({
      where: { id }
    });
    
    if (!skill) {
      return NextResponse.json({ error: 'Skill not found' }, { status: 404 });
    }
    
    // Update last opened
    await db.skill.update({
      where: { id },
      data: { lastOpened: new Date() }
    });
    
    return NextResponse.json({
      id: skill.id,
      resolvedPath: skill.resolvedPath,
      filePath: skill.filePath,
      isDirectory: skill.isDirectory,
      name: skill.name,
      description: skill.description,
      content: skill.content,
      frontmatter: JSON.parse(skill.frontmatter || '{}'),
      toolSources: skill.toolSources ? skill.toolSources.split(',').filter(Boolean) : [],
      installedPaths: JSON.parse(skill.installedPaths || '[]'),
      isFavorite: skill.isFavorite,
      lastOpened: skill.lastOpened?.toISOString() || null,
      fileModifiedDate: skill.fileModifiedDate.toISOString(),
      fileSize: skill.fileSize,
      isGlobal: skill.isGlobal,
      projectName: skill.projectName
    });
  } catch (error) {
    console.error('Error fetching skill:', error);
    return NextResponse.json({ error: 'Failed to fetch skill' }, { status: 500 });
  }
}

// PUT /api/skills/[id] - Update a skill
export async function PUT(request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const body = await request.json();
    
    const skill = await db.skill.findUnique({ where: { id } });
    if (!skill) {
      return NextResponse.json({ error: 'Skill not found' }, { status: 404 });
    }
    
    // Update content in database
    const frontmatter = body.frontmatter || {};
    const content = body.content || skill.content;
    
    // Write to file
    try {
      const fileContent = serializeSkillContent(frontmatter, content);
      fs.writeFileSync(skill.filePath, fileContent, 'utf-8');
    } catch (fileError) {
      console.error('Error writing file:', fileError);
      return NextResponse.json({ error: 'Failed to write file' }, { status: 500 });
    }
    
    // Update database
    const updated = await db.skill.update({
      where: { id },
      data: {
        content,
        frontmatter: JSON.stringify(frontmatter),
        name: frontmatter.name || skill.name,
        description: frontmatter.description || skill.description,
        fileModifiedDate: new Date()
      }
    });
    
    return NextResponse.json({
      id: updated.id,
      name: updated.name,
      description: updated.description,
      content: updated.content,
      frontmatter: JSON.parse(updated.frontmatter || '{}')
    });
  } catch (error) {
    console.error('Error updating skill:', error);
    return NextResponse.json({ error: 'Failed to update skill' }, { status: 500 });
  }
}

// DELETE /api/skills/[id] - Delete a skill
export async function DELETE(request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    
    const skill = await db.skill.findUnique({ where: { id } });
    if (!skill) {
      return NextResponse.json({ error: 'Skill not found' }, { status: 404 });
    }
    
    // Delete from filesystem
    try {
      const installedPaths: string[] = JSON.parse(skill.installedPaths || '[]');
      for (const filePath of installedPaths) {
        if (fs.existsSync(filePath)) {
          if (skill.isDirectory) {
            const parentDir = path.dirname(filePath);
            fs.rmSync(parentDir, { recursive: true, force: true });
          } else {
            fs.unlinkSync(filePath);
          }
        }
      }
    } catch (fileError) {
      console.error('Error deleting file:', fileError);
      return NextResponse.json({ error: 'Failed to delete file' }, { status: 500 });
    }
    
    // Delete from database
    await db.skill.delete({ where: { id } });
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting skill:', error);
    return NextResponse.json({ error: 'Failed to delete skill' }, { status: 500 });
  }
}

// PATCH /api/skills/[id] - Toggle favorite
export async function PATCH(request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const body = await request.json();
    
    const skill = await db.skill.findUnique({ where: { id } });
    if (!skill) {
      return NextResponse.json({ error: 'Skill not found' }, { status: 404 });
    }
    
    const updated = await db.skill.update({
      where: { id },
      data: {
        isFavorite: body.isFavorite !== undefined ? body.isFavorite : !skill.isFavorite
      }
    });
    
    return NextResponse.json({ isFavorite: updated.isFavorite });
  } catch (error) {
    console.error('Error updating skill:', error);
    return NextResponse.json({ error: 'Failed to update skill' }, { status: 500 });
  }
}
