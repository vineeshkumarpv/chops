import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/skills - Get all skills
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search');
    const tool = searchParams.get('tool');
    const favorite = searchParams.get('favorite');
    
    const skills = await db.skill.findMany({
      orderBy: { name: 'asc' }
    });
    
    // Filter by search
    let filtered = skills;
    if (search) {
      const searchLower = search.toLowerCase();
      filtered = skills.filter(s => 
        s.name.toLowerCase().includes(searchLower) ||
        s.description.toLowerCase().includes(searchLower) ||
        s.content.toLowerCase().includes(searchLower)
      );
    }
    
    // Filter by tool
    if (tool) {
      filtered = filtered.filter(s => s.toolSources.includes(tool));
    }
    
    // Filter by favorite
    if (favorite === 'true') {
      filtered = filtered.filter(s => s.isFavorite);
    }
    
    // Transform to API format
    const result = filtered.map(s => ({
      id: s.id,
      resolvedPath: s.resolvedPath,
      filePath: s.filePath,
      isDirectory: s.isDirectory,
      name: s.name,
      description: s.description,
      content: s.content,
      frontmatter: JSON.parse(s.frontmatter || '{}'),
      toolSources: s.toolSources ? s.toolSources.split(',').filter(Boolean) : [],
      installedPaths: JSON.parse(s.installedPaths || '[]'),
      isFavorite: s.isFavorite,
      lastOpened: s.lastOpened?.toISOString() || null,
      fileModifiedDate: s.fileModifiedDate.toISOString(),
      fileSize: s.fileSize,
      isGlobal: s.isGlobal,
      projectName: s.projectName,
      collectionIds: [] // Not using collections in this version
    }));
    
    return NextResponse.json(result);
  } catch (error) {
    console.error('Error fetching skills:', error);
    return NextResponse.json({ error: 'Failed to fetch skills' }, { status: 500 });
  }
}
