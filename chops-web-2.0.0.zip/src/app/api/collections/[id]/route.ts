import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

interface Params {
  params: Promise<{ id: string }>;
}

// GET /api/collections/[id] - Get a single collection
export async function GET(request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    
    const collection = await db.collection.findUnique({
      where: { id },
      include: { skills: true }
    });
    
    if (!collection) {
      return NextResponse.json({ error: 'Collection not found' }, { status: 404 });
    }
    
    return NextResponse.json({
      id: collection.id,
      name: collection.name,
      icon: collection.icon,
      sortOrder: collection.sortOrder,
      skillIds: collection.skills.map(s => s.skillId)
    });
  } catch (error) {
    console.error('Error fetching collection:', error);
    return NextResponse.json({ error: 'Failed to fetch collection' }, { status: 500 });
  }
}

// PUT /api/collections/[id] - Update a collection
export async function PUT(request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const body = await request.json();
    
    const collection = await db.collection.findUnique({ where: { id } });
    if (!collection) {
      return NextResponse.json({ error: 'Collection not found' }, { status: 404 });
    }
    
    const updated = await db.collection.update({
      where: { id },
      data: {
        name: body.name,
        icon: body.icon
      }
    });
    
    return NextResponse.json({
      id: updated.id,
      name: updated.name,
      icon: updated.icon,
      sortOrder: updated.sortOrder,
      skillIds: []
    });
  } catch (error) {
    console.error('Error updating collection:', error);
    return NextResponse.json({ error: 'Failed to update collection' }, { status: 500 });
  }
}

// DELETE /api/collections/[id] - Delete a collection
export async function DELETE(request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    
    await db.collection.delete({ where: { id } });
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting collection:', error);
    return NextResponse.json({ error: 'Failed to delete collection' }, { status: 500 });
  }
}

// POST /api/collections/[id] - Add skill to collection
export async function POST(request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { skillId } = body;
    
    if (!skillId) {
      return NextResponse.json({ error: 'Skill ID is required' }, { status: 400 });
    }
    
    await db.skillCollection.create({
      data: {
        skillId,
        collectionId: id
      }
    });
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error adding to collection:', error);
    return NextResponse.json({ error: 'Failed to add to collection' }, { status: 500 });
  }
}

// DELETE - Remove skill from collection
export async function PATCH(request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { skillId } = body;
    
    if (!skillId) {
      return NextResponse.json({ error: 'Skill ID is required' }, { status: 400 });
    }
    
    await db.skillCollection.delete({
      where: {
        skillId_collectionId: {
          skillId,
          collectionId: id
        }
      }
    });
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error removing from collection:', error);
    return NextResponse.json({ error: 'Failed to remove from collection' }, { status: 500 });
  }
}
