import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/collections - Get all collections
export async function GET() {
  try {
    const collections = await db.collection.findMany({
      include: {
        skills: {
          include: {
            skill: true
          }
        }
      },
      orderBy: [
        { sortOrder: 'asc' },
        { name: 'asc' }
      ]
    });
    
    return NextResponse.json(collections.map(c => ({
      id: c.id,
      name: c.name,
      icon: c.icon,
      sortOrder: c.sortOrder,
      skillIds: c.skills.map(s => s.skillId)
    })));
  } catch (error) {
    console.error('Error fetching collections:', error);
    return NextResponse.json({ error: 'Failed to fetch collections' }, { status: 500 });
  }
}

// POST /api/collections - Create a collection
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, icon = 'folder' } = body;
    
    if (!name) {
      return NextResponse.json({ error: 'Name is required' }, { status: 400 });
    }
    
    // Get max sort order
    const maxOrder = await db.collection.aggregate({
      _max: { sortOrder: true }
    });
    
    const collection = await db.collection.create({
      data: {
        name,
        icon,
        sortOrder: (maxOrder._max.sortOrder || 0) + 1
      }
    });
    
    return NextResponse.json({
      id: collection.id,
      name: collection.name,
      icon: collection.icon,
      sortOrder: collection.sortOrder,
      skillIds: []
    });
  } catch (error) {
    console.error('Error creating collection:', error);
    return NextResponse.json({ error: 'Failed to create collection' }, { status: 500 });
  }
}
