'use client'

import { useState, useEffect, useCallback } from 'react'

// Types
interface Skill {
  id: string
  resolvedPath: string
  filePath: string
  isDirectory: boolean
  name: string
  description: string
  content: string
  frontmatter: Record<string, string>
  toolSources: string[]
  installedPaths: string[]
  isFavorite: boolean
  lastOpened: string | null
  fileModifiedDate: string
  fileSize: number
  isGlobal: boolean
  projectName: string | null
}

interface Tool {
  tool: string
  displayName: string
  color: string
  icon: string
  installed: boolean
  paths: string[]
}

// Tool display info
const toolIcons: Record<string, string> = {
  agents: '🌍',
  claude: '🧠',
  cursor: '🖱️',
  windsurf: '🌬️',
  codex: '📚',
  copilot: '✈️',
  aider: '🔧',
  amp: '⚡',
  openclaw: '🖥️',
  opencode: '💻',
  pi: '✨',
  antigravity: '🚀',
  claudeDesktop: '🖥️',
  custom: '📁'
}

export default function ChopsWeb() {
  // State
  const [skills, setSkills] = useState<Skill[]>([])
  const [tools, setTools] = useState<Tool[]>([])
  const [selectedSkill, setSelectedSkill] = useState<Skill | null>(null)
  const [currentFilter, setCurrentFilter] = useState<string>('all')
  const [searchQuery, setSearchQuery] = useState('')
  const [isLoading, setIsLoading] = useState(true)
  const [isScanning, setIsScanning] = useState(false)
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false)
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null)
  const [scanInfo, setScanInfo] = useState<{ total: number; lastScan: string } | null>(null)

  // Fetch data
  const fetchData = useCallback(async () => {
    setIsLoading(true)
    try {
      const [skillsRes, toolsRes] = await Promise.all([
        fetch('/api/skills'),
        fetch('/api/tools')
      ])
      
      if (skillsRes.ok) setSkills(await skillsRes.json())
      if (toolsRes.ok) setTools(await toolsRes.json())
    } catch (error) {
      console.error('Error fetching data:', error)
      showToast('Failed to load data', 'error')
    } finally {
      setIsLoading(false)
    }
  }, [])

  // Scan filesystem
  const scanFilesystem = useCallback(async () => {
    setIsScanning(true)
    try {
      const res = await fetch('/api/scan', { method: 'POST' })
      if (res.ok) {
        const data = await res.json()
        showToast(data.message, 'success')
        setScanInfo({ total: data.total, lastScan: new Date().toLocaleTimeString() })
        fetchData()
      }
    } catch (error) {
      console.error('Error scanning:', error)
      showToast('Failed to scan filesystem', 'error')
    } finally {
      setIsScanning(false)
    }
  }, [fetchData])

  useEffect(() => {
    fetchData().then(() => {
      // Trigger scan on first load
      scanFilesystem()
    })
  }, [fetchData, scanFilesystem])

  // Show toast
  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type })
    setTimeout(() => setToast(null), 3000)
  }

  // Group skills by project
  const projectGroups = useCallback(() => {
    const groups: Record<string, Skill[]> = { 'Global': [], 'Projects': {} as Record<string, Skill[]> }
    
    for (const skill of skills) {
      if (skill.isGlobal) {
        groups['Global'].push(skill)
      } else if (skill.projectName) {
        if (!groups['Projects'][skill.projectName]) {
          groups['Projects'][skill.projectName] = []
        }
        groups['Projects'][skill.projectName].push(skill)
      }
    }
    
    return groups
  }, [skills])

  // Filter skills
  const filteredSkills = skills.filter(skill => {
    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      if (!skill.name.toLowerCase().includes(query) &&
          !skill.description.toLowerCase().includes(query) &&
          !skill.content.toLowerCase().includes(query) &&
          !(skill.projectName?.toLowerCase().includes(query))) {
        return false
      }
    }
    
    // Category filter
    if (currentFilter === 'favorites') {
      return skill.isFavorite
    }
    if (currentFilter === 'global') {
      return skill.isGlobal
    }
    if (currentFilter === 'projects') {
      return !skill.isGlobal && skill.projectName
    }
    if (currentFilter.startsWith('tool:')) {
      const tool = currentFilter.substring(5)
      return skill.toolSources.includes(tool)
    }
    if (currentFilter.startsWith('project:')) {
      const projectName = currentFilter.substring(8)
      return skill.projectName === projectName
    }
    
    return true
  }).sort((a, b) => {
    // Sort by project name first, then by skill name
    if (a.isGlobal !== b.isGlobal) {
      return a.isGlobal ? -1 : 1
    }
    if (a.projectName && b.projectName && a.projectName !== b.projectName) {
      return a.projectName.localeCompare(b.projectName)
    }
    return a.name.localeCompare(b.name)
  })

  // Select skill
  const selectSkill = async (skill: Skill) => {
    if (hasUnsavedChanges && selectedSkill) {
      await saveSkill()
    }
    
    try {
      const res = await fetch(`/api/skills/${skill.id}`)
      if (res.ok) {
        const fullSkill = await res.json()
        setSelectedSkill(fullSkill)
        setHasUnsavedChanges(false)
      }
    } catch (error) {
      console.error('Error fetching skill:', error)
    }
  }

  // Save skill
  const saveSkill = async () => {
    if (!selectedSkill || !hasUnsavedChanges) return
    
    try {
      const res = await fetch(`/api/skills/${selectedSkill.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: selectedSkill.content,
          frontmatter: selectedSkill.frontmatter
        })
      })
      
      if (res.ok) {
        setHasUnsavedChanges(false)
        showToast('Saved', 'success')
      } else {
        showToast('Failed to save', 'error')
      }
    } catch (error) {
      console.error('Error saving:', error)
      showToast('Failed to save', 'error')
    }
  }

  // Toggle favorite
  const toggleFavorite = async () => {
    if (!selectedSkill) return
    
    try {
      const res = await fetch(`/api/skills/${selectedSkill.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isFavorite: !selectedSkill.isFavorite })
      })
      
      if (res.ok) {
        const data = await res.json()
        setSelectedSkill({ ...selectedSkill, isFavorite: data.isFavorite })
        setSkills(skills.map(s => s.id === selectedSkill.id ? { ...s, isFavorite: data.isFavorite } : s))
        showToast(data.isFavorite ? 'Added to favorites' : 'Removed from favorites', 'success')
      }
    } catch (error) {
      console.error('Error toggling favorite:', error)
      showToast('Failed to update favorite', 'error')
    }
  }

  // Delete skill
  const deleteSkill = async () => {
    if (!selectedSkill) return
    
    if (!confirm(`Are you sure you want to delete "${selectedSkill.name}"?\n\nThis will delete the file from disk.`)) {
      return
    }
    
    try {
      const res = await fetch(`/api/skills/${selectedSkill.id}`, { method: 'DELETE' })
      
      if (res.ok) {
        setSkills(skills.filter(s => s.id !== selectedSkill.id))
        setSelectedSkill(null)
        showToast('Skill deleted', 'success')
      } else {
        showToast('Failed to delete', 'error')
      }
    } catch (error) {
      console.error('Error deleting:', error)
      showToast('Failed to delete', 'error')
    }
  }

  // Get stats
  const allCount = skills.length
  const favoritesCount = skills.filter(s => s.isFavorite).length
  const globalCount = skills.filter(s => s.isGlobal).length
  const projectCount = skills.filter(s => !s.isGlobal && s.projectName).length
  const projectNames = [...new Set(skills.filter(s => s.projectName).map(s => s.projectName!))]
  const installedToolsCount = tools.filter(t => t.installed).length

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-orange-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-400">Scanning $HOME for skills...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col">
      {/* Header */}
      <header className="bg-gray-800 border-b border-gray-700 px-4 py-3 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg flex items-center justify-center">
            <span className="text-sm">📝</span>
          </div>
          <h1 className="text-lg font-semibold">Chops</h1>
          <span className="text-xs bg-orange-600/30 text-orange-300 px-2 py-0.5 rounded-full">Web UI</span>
        </div>
        <div className="flex items-center gap-2">
          {scanInfo && (
            <span className="text-xs text-gray-400 mr-2">
              {scanInfo.total} skills • Last scan: {scanInfo.lastScan}
            </span>
          )}
          <button
            onClick={scanFilesystem}
            disabled={isScanning}
            className="px-3 py-1.5 text-sm bg-gray-700 hover:bg-gray-600 rounded-md transition flex items-center gap-2 disabled:opacity-50"
          >
            {isScanning ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                Scanning...
              </>
            ) : (
              <>
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
                Rescan $HOME
              </>
            )}
          </button>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <aside className="w-56 bg-gray-800 border-r border-gray-700 flex flex-col shrink-0">
          {/* Filters */}
          <div className="p-3 border-b border-gray-700">
            <h2 className="text-xs font-semibold text-gray-400 uppercase mb-2">Filters</h2>
            <nav className="space-y-1">
              <button
                onClick={() => setCurrentFilter('all')}
                className={`w-full text-left px-3 py-2 rounded-md text-sm flex items-center justify-between transition ${currentFilter === 'all' ? 'bg-orange-600 text-white' : 'hover:bg-gray-700'}`}
              >
                <span>📋 All Skills</span>
                <span className="text-xs opacity-75">{allCount}</span>
              </button>
              <button
                onClick={() => setCurrentFilter('favorites')}
                className={`w-full text-left px-3 py-2 rounded-md text-sm flex items-center justify-between transition ${currentFilter === 'favorites' ? 'bg-orange-600 text-white' : 'hover:bg-gray-700'}`}
              >
                <span>⭐ Favorites</span>
                <span className="text-xs opacity-75">{favoritesCount}</span>
              </button>
              <button
                onClick={() => setCurrentFilter('global')}
                className={`w-full text-left px-3 py-2 rounded-md text-sm flex items-center justify-between transition ${currentFilter === 'global' ? 'bg-orange-600 text-white' : 'hover:bg-gray-700'}`}
              >
                <span>🌍 Global</span>
                <span className="text-xs opacity-75">{globalCount}</span>
              </button>
              <button
                onClick={() => setCurrentFilter('projects')}
                className={`w-full text-left px-3 py-2 rounded-md text-sm flex items-center justify-between transition ${currentFilter === 'projects' ? 'bg-orange-600 text-white' : 'hover:bg-gray-700'}`}
              >
                <span>📁 Projects</span>
                <span className="text-xs opacity-75">{projectCount}</span>
              </button>
            </nav>
          </div>

          {/* Tools */}
          <div className="p-3 border-b border-gray-700 flex-1 overflow-y-auto">
            <h2 className="text-xs font-semibold text-gray-400 uppercase mb-2">Tools</h2>
            <nav className="space-y-1">
              {tools.filter(t => t.installed).map(tool => {
                const count = skills.filter(s => s.toolSources.includes(tool.tool)).length
                return (
                  <button
                    key={tool.tool}
                    onClick={() => setCurrentFilter(`tool:${tool.tool}`)}
                    className={`w-full text-left px-3 py-2 rounded-md text-sm flex items-center justify-between transition ${currentFilter === `tool:${tool.tool}` ? 'bg-orange-600 text-white' : 'hover:bg-gray-700'}`}
                  >
                    <span className="flex items-center gap-2">
                      <span>{toolIcons[tool.tool] || '📁'}</span>
                      <span className="truncate">{tool.displayName}</span>
                    </span>
                    <span className="text-xs opacity-75">{count}</span>
                  </button>
                )
              })}
            </nav>
          </div>

          {/* Projects */}
          {projectNames.length > 0 && (
            <div className="p-3 border-t border-gray-700 max-h-48 overflow-y-auto">
              <h2 className="text-xs font-semibold text-gray-400 uppercase mb-2">Projects</h2>
              <nav className="space-y-1">
                {projectNames.sort().map(name => {
                  const count = skills.filter(s => s.projectName === name).length
                  return (
                    <button
                      key={name}
                      onClick={() => setCurrentFilter(`project:${name}`)}
                      className={`w-full text-left px-3 py-2 rounded-md text-sm flex items-center justify-between transition ${currentFilter === `project:${name}` ? 'bg-orange-600 text-white' : 'hover:bg-gray-700'}`}
                    >
                      <span className="truncate">{name}</span>
                      <span className="text-xs opacity-75">{count}</span>
                    </button>
                  )
                })}
              </nav>
            </div>
          )}
        </aside>

        {/* Skill List */}
        <div className="w-80 bg-gray-850 border-r border-gray-700 flex flex-col shrink-0" style={{ background: '#1a1a1f' }}>
          {/* Search */}
          <div className="p-3 border-b border-gray-700">
            <input
              type="text"
              placeholder="Search skills, projects..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-md text-sm focus:outline-none focus:border-orange-500"
            />
          </div>

          {/* List */}
          <div className="flex-1 overflow-y-auto">
            {filteredSkills.length === 0 ? (
              <div className="p-4 text-center text-gray-500">
                <p className="text-sm">No skills found</p>
                <p className="text-xs mt-2">Click "Rescan $HOME" to search for skills</p>
              </div>
            ) : (
              filteredSkills.map(skill => {
                const primaryTool = skill.toolSources[0] || 'custom'
                const tool = tools.find(t => t.tool === primaryTool)
                
                return (
                  <button
                    key={skill.id}
                    onClick={() => selectSkill(skill)}
                    className={`w-full text-left p-3 border-b border-gray-800 hover:bg-gray-800 transition ${selectedSkill?.id === skill.id ? 'bg-gray-800 border-l-2 border-l-orange-500' : ''}`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      {skill.isFavorite && <span className="text-yellow-500 text-xs">★</span>}
                      <span className="font-medium text-sm truncate">{skill.name}</span>
                      {!skill.isGlobal && skill.projectName && (
                        <span className="text-xs bg-blue-600/30 text-blue-300 px-1.5 py-0.5 rounded truncate max-w-[80px]">
                          {skill.projectName}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-gray-500 truncate mb-1">{skill.description || 'No description'}</p>
                    <div className="flex items-center gap-2">
                      <span
                        className="text-xs px-2 py-0.5 rounded"
                        style={{ background: `${tool?.color || '#9E9E9E'}22`, color: tool?.color || '#9E9E9E' }}
                      >
                        {toolIcons[primaryTool]} {tool?.displayName || 'Custom'}
                      </span>
                      {skill.toolSources.length > 1 && (
                        <span className="text-xs px-2 py-0.5 rounded bg-gray-700 text-gray-400">
                          +{skill.toolSources.length - 1}
                        </span>
                      )}
                    </div>
                  </button>
                )
              })
            )}
          </div>
        </div>

        {/* Detail View */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {selectedSkill ? (
            <>
              {/* Detail Header */}
              <div className="p-4 border-b border-gray-700 bg-gray-800">
                <div className="flex items-center gap-3 mb-2">
                  {selectedSkill.isFavorite && <span className="text-yellow-500">★</span>}
                  <h2 className="text-xl font-semibold">{selectedSkill.name}</h2>
                  {!selectedSkill.isGlobal && selectedSkill.projectName && (
                    <span className="text-sm bg-blue-600/30 text-blue-300 px-2 py-0.5 rounded">
                      {selectedSkill.projectName}
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-4 text-sm text-gray-400 mb-3">
                  <span>
                    {toolIcons[selectedSkill.toolSources[0]]} {tools.find(t => t.tool === selectedSkill.toolSources[0])?.displayName || 'Custom'}
                  </span>
                  <span className="truncate max-w-xs" title={selectedSkill.filePath}>
                    📍 {selectedSkill.filePath.replace(process.env.HOME || '~', '~')}
                  </span>
                  <span>📅 {new Date(selectedSkill.fileModifiedDate).toLocaleDateString()}</span>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={toggleFavorite}
                    className={`px-3 py-1.5 text-sm rounded-md transition ${selectedSkill.isFavorite ? 'bg-yellow-600/20 text-yellow-400 hover:bg-yellow-600/30' : 'bg-gray-700 hover:bg-gray-600'}`}
                  >
                    {selectedSkill.isFavorite ? '★ Favorited' : '☆ Favorite'}
                  </button>
                  <button
                    onClick={saveSkill}
                    disabled={!hasUnsavedChanges}
                    className={`px-3 py-1.5 text-sm rounded-md transition ${hasUnsavedChanges ? 'bg-orange-600 hover:bg-orange-500' : 'bg-gray-700 text-gray-500'}`}
                  >
                    💾 Save
                  </button>
                  <button
                    onClick={deleteSkill}
                    className="px-3 py-1.5 text-sm bg-red-600/20 text-red-400 hover:bg-red-600/30 rounded-md transition"
                  >
                    🗑️ Delete
                  </button>
                </div>
              </div>

              {/* Editor */}
              <div className="flex-1 overflow-hidden">
                <textarea
                  value={selectedSkill.content}
                  onChange={(e) => {
                    setSelectedSkill({ ...selectedSkill, content: e.target.value })
                    setHasUnsavedChanges(true)
                  }}
                  className="w-full h-full p-4 bg-gray-900 text-gray-100 font-mono text-sm resize-none focus:outline-none"
                  placeholder="Skill content..."
                  spellCheck={false}
                />
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-gray-500">
              <div className="text-center">
                <div className="text-5xl mb-4">📄</div>
                <h3 className="text-lg font-medium text-gray-300 mb-2">Select a Skill</h3>
                <p className="text-sm">Choose a skill from the list to view and edit it.</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Status Bar */}
      <footer className="bg-orange-600 px-4 py-1 text-xs text-white flex items-center gap-6 shrink-0">
        <span>{allCount} skill{allCount !== 1 ? 's' : ''}</span>
        <span>{installedToolsCount} tool{installedToolsCount !== 1 ? 's' : ''} detected</span>
        <span>{projectNames.length} project{projectNames.length !== 1 ? 's' : ''}</span>
        {hasUnsavedChanges && <span className="text-yellow-200">● Unsaved changes</span>}
      </footer>

      {/* Toast */}
      {toast && (
        <div className={`fixed bottom-16 right-4 px-4 py-2 rounded-md shadow-lg z-50 ${toast.type === 'success' ? 'bg-green-600' : 'bg-red-600'}`}>
          {toast.message}
        </div>
      )}
    </div>
  )
}
