// Tool source enum - supported AI coding tools
export enum ToolSource {
  Agents = 'agents',
  Claude = 'claude',
  Cursor = 'cursor',
  Windsurf = 'windsurf',
  Codex = 'codex',
  Copilot = 'copilot',
  Aider = 'aider',
  Amp = 'amp',
  OpenClaw = 'openclaw',
  OpenCode = 'opencode',
  Pi = 'pi',
  Gemini = 'gemini',
  ClaudeDesktop = 'claudeDesktop',
  Custom = 'custom'
}

export interface ToolInfo {
  displayName: string;
  iconName: string;
  color: string;
  globalPaths: string[];
}

export const ToolSourceInfo: Record<ToolSource, ToolInfo> = {
  [ToolSource.Agents]: {
    displayName: 'Global Agents',
    iconName: 'globe',
    color: '#00D9A5',
    globalPaths: []
  },
  [ToolSource.Claude]: {
    displayName: 'Claude Code',
    iconName: 'brain',
    color: '#FF9500',
    globalPaths: []
  },
  [ToolSource.Cursor]: {
    displayName: 'Cursor',
    iconName: 'cursor',
    color: '#007AFF',
    globalPaths: []
  },
  [ToolSource.Windsurf]: {
    displayName: 'Windsurf',
    iconName: 'wind',
    color: '#00BCD4',
    globalPaths: []
  },
  [ToolSource.Codex]: {
    displayName: 'Codex',
    iconName: 'book',
    color: '#4CAF50',
    globalPaths: []
  },
  [ToolSource.Copilot]: {
    displayName: 'Copilot',
    iconName: 'airplane',
    color: '#9C27B0',
    globalPaths: []
  },
  [ToolSource.Aider]: {
    displayName: 'Aider',
    iconName: 'wrench',
    color: '#FFC107',
    globalPaths: []
  },
  [ToolSource.Amp]: {
    displayName: 'Amp',
    iconName: 'bolt',
    color: '#E91E63',
    globalPaths: []
  },
  [ToolSource.OpenClaw]: {
    displayName: 'OpenClaw',
    iconName: 'server',
    color: '#3F51B5',
    globalPaths: []
  },
  [ToolSource.OpenCode]: {
    displayName: 'OpenCode',
    iconName: 'terminal',
    color: '#F44336',
    globalPaths: []
  },
  [ToolSource.Pi]: {
    displayName: 'Pi',
    iconName: 'sparkles',
    color: '#00BCD4',
    globalPaths: []
  },
  [ToolSource.Gemini]: {
    displayName: 'Gemini CLI',
    iconName: 'sparkles',
    color: '#4285F4',
    globalPaths: []
  },
  [ToolSource.ClaudeDesktop]: {
    displayName: 'Claude Desktop',
    iconName: 'desktop',
    color: '#FF9500',
    globalPaths: []
  },
  [ToolSource.Custom]: {
    displayName: 'Custom',
    iconName: 'folder',
    color: '#9E9E9E',
    globalPaths: []
  }
};

// Get global paths for a tool on Linux
export function getGlobalPaths(tool: ToolSource, homeDir: string, configHome: string): string[] {
  switch (tool) {
    case ToolSource.Claude:
      return [`${homeDir}/.claude/skills`];
    case ToolSource.Cursor:
      return [`${homeDir}/.cursor/skills`, `${homeDir}/.cursor/rules`];
    case ToolSource.Windsurf:
      return [`${homeDir}/.codeium/windsurf/memories`, `${homeDir}/.windsurf/rules`];
    case ToolSource.Codex:
      return [`${homeDir}/.codex/skills`];
    case ToolSource.Copilot:
      return [`${homeDir}/.copilot/skills`];
    case ToolSource.Aider:
      return [];
    case ToolSource.Amp:
      return [`${configHome}/amp/skills`];
    case ToolSource.OpenClaw:
      return [];
    case ToolSource.OpenCode:
      return [`${configHome}/opencode/skills`];
    case ToolSource.Pi:
      return [`${homeDir}/.pi/agent/skills`];
    case ToolSource.Agents:
      return [`${homeDir}/.agents/skills`];
    case ToolSource.Gemini:
      return [`${homeDir}/.gemini/skills`];
    case ToolSource.ClaudeDesktop:
      return [];
    case ToolSource.Custom:
      return [];
    default:
      return [];
  }
}

// Skill type for API responses
export interface Skill {
  id: string;
  resolvedPath: string;
  filePath: string;
  isDirectory: boolean;
  name: string;
  description: string;
  content: string;
  frontmatter: Record<string, string>;
  toolSources: string[];
  installedPaths: string[];
  isFavorite: boolean;
  lastOpened: string | null;
  fileModifiedDate: string;
  fileSize: number;
  isGlobal: boolean;
  collectionIds: string[];
}

// Collection type
export interface Collection {
  id: string;
  name: string;
  icon: string;
  sortOrder: number;
  skillIds: string[];
}
