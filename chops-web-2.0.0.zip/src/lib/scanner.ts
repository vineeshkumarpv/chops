import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { ToolSource, ToolSourceInfo } from './types';
import { parseSkillFile } from './parser';
import { db } from './db';

// Tool directories to search for
const TOOL_DIRECTORY_NAMES = new Set([
  '.claude',
  '.cursor',
  '.gemini',
  '.codex',
  '.agents',
  '.copilot',
  '.windsurf',
  '.codeium',
  '.pi',
  '.aider',
]);

// Map directory names to tool sources
const DIRECTORY_TO_TOOL: Record<string, ToolSource> = {
  '.claude': ToolSource.Claude,
  '.cursor': ToolSource.Cursor,
  '.gemini': ToolSource.Gemini,
  '.codex': ToolSource.Codex,
  '.agents': ToolSource.Agents,
  '.copilot': ToolSource.Copilot,
  '.windsurf': ToolSource.Windsurf,
  '.codeium': ToolSource.Windsurf,
  '.pi': ToolSource.Pi,
  '.aider': ToolSource.Aider,
};

// Directories to skip during recursive scan
const SKIP_DIRECTORIES = new Set([
  // Version control
  '.git',
  '.svn',
  '.hg',
  
  // Package managers / caches
  'node_modules',
  '.npm',
  '.yarn',
  '.pnpm',
  '.cache',
  '__pycache__',
  '.python-cache',
  'venv',
  '.venv',
  'env',
  
  // Build outputs
  'dist',
  'build',
  'out',
  'target',
  '.next',
  '.nuxt',
  '.output',
  
  // IDE / Editor
  '.idea',
  '.vscode',
  '.vscode-server',
  
  // System / Hidden
  '.Trash',
  '.local',
  '.config',
  'Library',
  'Applications',
  'Desktop',
  'Documents',
  'Downloads',
  'Movies',
  'Music',
  'Pictures',
  'Public',
  
  // Large data directories
  '.docker',
  '.kube',
  '.minikube',
  '.terraform',
  '.vagrant',
  
  // Logs and temp
  'logs',
  'tmp',
  'temp',
  '.logs',
  
  // Other
  'coverage',
  '.nyc_output',
  '.pytest_cache',
  '.mypy_cache',
]);

// Skill subdirectories to check within tool directories
const SKILL_SUBDIRS = [
  'skills',
  'rules',
  'memories',
  'commands',
];

// Files to ignore when scanning
const IGNORED_FILE_NAMES = new Set([
  'README.md',
  'README',
  'CLAUDE.md',
  'AGENTS.md',
  'AGENTS.override.md',
  'global_rules.md',
  'SYSTEM.md',
  'APPEND_SYSTEM.md',
  'LICENSE.md',
  'LICENSE',
  'CHANGELOG.md',
  'settings.json',
  'config.json',
  'argv.json',
  'auth.json',
  'config.toml',
]);

interface ScannedSkillData {
  filePath: string;
  resolvedPath: string;
  toolSource: ToolSource;
  isDirectory: boolean;
  isGlobal: boolean;
  projectName: string | null;
  name: string;
  description: string;
  content: string;
  frontmatter: Record<string, string>;
  modDate: Date;
  fileSize: number;
}

interface ScanProgress {
  directoriesScanned: number;
  toolDirectoriesFound: number;
  skillsFound: number;
}

class SkillScanner {
  private homeDir: string;
  private configHome: string;
  private progress: ScanProgress = {
    directoriesScanned: 0,
    toolDirectoriesFound: 0,
    skillsFound: 0
  };

  constructor() {
    this.homeDir = os.homedir();
    this.configHome = process.env.XDG_CONFIG_HOME || path.join(this.homeDir, '.config');
  }

  /**
   * Get all installed tools based on discovered directories
   */
  getInstalledTools(): { tool: ToolSource; installed: boolean; info: typeof ToolSourceInfo[ToolSource] }[] {
    const discoveredTools = new Set<ToolSource>();
    
    // Check for tool directories in home
    for (const [dirName, toolSource] of Object.entries(DIRECTORY_TO_TOOL)) {
      const toolPath = path.join(this.homeDir, dirName);
      if (fs.existsSync(toolPath)) {
        discoveredTools.add(toolSource);
      }
    }
    
    // Also check .config for some tools
    const configTools: Record<string, ToolSource> = {
      'amp': ToolSource.Amp,
      'opencode': ToolSource.OpenCode,
    };
    
    for (const [dirName, toolSource] of Object.entries(configTools)) {
      const configPath = path.join(this.configHome, dirName);
      if (fs.existsSync(configPath)) {
        discoveredTools.add(toolSource);
      }
    }
    
    // Always include aider and custom as available
    discoveredTools.add(ToolSource.Aider);
    discoveredTools.add(ToolSource.Custom);
    
    return Object.values(ToolSource).map(tool => ({
      tool,
      installed: discoveredTools.has(tool),
      info: ToolSourceInfo[tool]
    }));
  }

  /**
   * Scan all of $HOME recursively for tool directories
   */
  scanAll(): ScannedSkillData[] {
    console.log('[Scanner] Starting recursive scan of $HOME...');
    const startTime = Date.now();
    
    // Reset progress
    this.progress = {
      directoriesScanned: 0,
      toolDirectoriesFound: 0,
      skillsFound: 0
    };
    
    const results: ScannedSkillData[] = [];
    const scannedToolDirs = new Set<string>();
    
    // First, check for tool directories directly in $HOME
    this.scanHomeForToolDirectories(results, scannedToolDirs);
    
    // Then scan all subdirectories recursively
    this.scanDirectoryRecursively(this.homeDir, 0, results, scannedToolDirs);
    
    // Also scan .config for tool directories
    if (fs.existsSync(this.configHome)) {
      this.scanConfigDirectory(results, scannedToolDirs);
    }
    
    // Scan CLI plugins for Claude
    this.collectFromCLIPlugins(results);
    
    const elapsed = Date.now() - startTime;
    console.log(`[Scanner] Scan complete: ${results.length} skills found in ${elapsed}ms`);
    console.log(`[Scanner] Scanned ${this.progress.directoriesScanned} directories, found ${this.progress.toolDirectoriesFound} tool directories`);
    
    return results;
  }

  /**
   * Scan $HOME directly for tool directories
   */
  private scanHomeForToolDirectories(
    results: ScannedSkillData[],
    scannedToolDirs: Set<string>
  ): void {
    try {
      const entries = fs.readdirSync(this.homeDir, { withFileTypes: true });
      
      for (const entry of entries) {
        if (!entry.isDirectory()) continue;
        if (!entry.name.startsWith('.')) continue;
        
        const toolDir = path.join(this.homeDir, entry.name);
        
        if (TOOL_DIRECTORY_NAMES.has(entry.name)) {
          this.progress.toolDirectoriesFound++;
          scannedToolDirs.add(toolDir);
          
          const toolSource = DIRECTORY_TO_TOOL[entry.name] || ToolSource.Custom;
          this.scanToolDirectory(toolDir, toolSource, true, null, results);
        }
      }
    } catch (error) {
      console.error('[Scanner] Error scanning home directory:', error);
    }
  }

  /**
   * Recursively scan directories looking for tool directories
   */
  private scanDirectoryRecursively(
    currentDir: string,
    depth: number,
    results: ScannedSkillData[],
    scannedToolDirs: Set<string>,
    projectName: string | null = null
  ): void {
    // Limit depth to avoid infinite recursion and performance issues
    if (depth > 10) return;
    
    try {
      const entries = fs.readdirSync(currentDir, { withFileTypes: true });
      this.progress.directoriesScanned++;
      
      // Determine project name from directory
      let currentProjectName = projectName;
      if (depth === 1 && !currentDir.startsWith('.') && !projectName) {
        // First level subdirectories might be projects
        const dirName = path.basename(currentDir);
        if (!SKIP_DIRECTORIES.has(dirName) && !dirName.startsWith('.')) {
          currentProjectName = dirName;
        }
      }
      
      for (const entry of entries) {
        const entryPath = path.join(currentDir, entry.name);
        
        if (entry.isDirectory()) {
          // Skip certain directories entirely
          if (SKIP_DIRECTORIES.has(entry.name)) continue;
          
          // Check if this is a tool directory we're looking for
          if (TOOL_DIRECTORY_NAMES.has(entry.name) && !scannedToolDirs.has(entryPath)) {
            this.progress.toolDirectoriesFound++;
            scannedToolDirs.add(entryPath);
            
            const toolSource = DIRECTORY_TO_TOOL[entry.name] || ToolSource.Custom;
            // Project-level skills
            this.scanToolDirectory(entryPath, toolSource, false, currentProjectName, results);
          } else {
            // Recurse into subdirectory
            this.scanDirectoryRecursively(
              entryPath, 
              depth + 1, 
              results, 
              scannedToolDirs,
              currentProjectName
            );
          }
        }
      }
    } catch (error) {
      // Ignore permission errors and such
      if ((error as NodeJS.ErrnoException).code !== 'EACCES' && 
          (error as NodeJS.ErrnoException).code !== 'ENOENT') {
        console.error(`[Scanner] Error scanning ${currentDir}:`, error);
      }
    }
  }

  /**
   * Scan .config directory for tool configurations
   */
  private scanConfigDirectory(
    results: ScannedSkillData[],
    scannedToolDirs: Set<string>
  ): void {
    const configTools: Record<string, ToolSource> = {
      'amp': ToolSource.Amp,
      'opencode': ToolSource.OpenCode,
    };
    
    for (const [dirName, toolSource] of Object.entries(configTools)) {
      const toolDir = path.join(this.configHome, dirName);
      if (fs.existsSync(toolDir) && !scannedToolDirs.has(toolDir)) {
        scannedToolDirs.add(toolDir);
        this.progress.toolDirectoriesFound++;
        this.scanToolDirectory(toolDir, toolSource, true, null, results);
      }
    }
  }

  /**
   * Scan a tool directory for skills
   */
  private scanToolDirectory(
    toolDir: string,
    toolSource: ToolSource,
    isGlobal: boolean,
    projectName: string | null,
    results: ScannedSkillData[]
  ): void {
    // Check skill subdirectories
    for (const subDir of SKILL_SUBDIRS) {
      const skillDir = path.join(toolDir, subDir);
      if (fs.existsSync(skillDir)) {
        this.collectFromSkillDirectory(skillDir, toolSource, isGlobal, projectName, results);
      }
    }
    
    // Also check for skills directly in the tool directory
    this.collectFromSkillDirectory(toolDir, toolSource, isGlobal, projectName, results);
    
    // For Claude, check plugins
    if (toolSource === ToolSource.Claude) {
      const pluginsDir = path.join(toolDir, 'plugins');
      if (fs.existsSync(pluginsDir)) {
        this.collectFromPluginsCache(pluginsDir, results);
      }
    }
  }

  /**
   * Collect skills from a directory
   */
  private collectFromSkillDirectory(
    directory: string,
    toolSource: ToolSource,
    isGlobal: boolean,
    projectName: string | null,
    results: ScannedSkillData[]
  ): void {
    if (!fs.existsSync(directory)) return;
    
    try {
      const entries = fs.readdirSync(directory, { withFileTypes: true });
      
      for (const entry of entries) {
        // Skip hidden files except .md files in special cases
        if (entry.name.startsWith('.') && !entry.name.endsWith('.md')) continue;
        
        const fullPath = path.join(directory, entry.name);
        
        if (entry.isDirectory()) {
          // Check for SKILL.md or AGENTS.md in directory
          const skillFile = path.join(fullPath, 'SKILL.md');
          const agentsFile = path.join(fullPath, 'AGENTS.md');
          
          if (fs.existsSync(skillFile)) {
            const data = this.collectSkillData(skillFile, toolSource, true, isGlobal, projectName);
            if (data) results.push(data);
          } else if (fs.existsSync(agentsFile)) {
            const data = this.collectSkillData(agentsFile, toolSource, true, isGlobal, projectName);
            if (data) results.push(data);
          }
        } else if (entry.isFile()) {
          const ext = path.extname(entry.name).toLowerCase();
          if (ext === '.md' || ext === '.mdc') {
            if (IGNORED_FILE_NAMES.has(entry.name)) continue;
            
            const data = this.collectSkillData(fullPath, toolSource, false, isGlobal, projectName);
            if (data) results.push(data);
          }
        }
      }
    } catch (error) {
      // Ignore errors for individual directories
    }
  }

  /**
   * Collect from Claude plugins cache
   */
  private collectFromPluginsCache(
    pluginsDir: string,
    results: ScannedSkillData[]
  ): void {
    const cacheDir = path.join(pluginsDir, 'cache');
    if (!fs.existsSync(cacheDir)) return;
    
    try {
      const entries = fs.readdirSync(cacheDir, { withFileTypes: true });
      
      for (const entry of entries) {
        if (!entry.isDirectory()) continue;
        
        // Publisher directory
        const publisherDir = path.join(cacheDir, entry.name);
        const pluginEntries = fs.readdirSync(publisherDir, { withFileTypes: true });
        
        for (const pluginEntry of pluginEntries) {
          if (!pluginEntry.isDirectory()) continue;
          
          // Plugin directory - check for version subdirectories
          const pluginDir = path.join(publisherDir, pluginEntry.name);
          const versionEntries = fs.readdirSync(pluginDir, { withFileTypes: true });
          
          for (const versionEntry of versionEntries) {
            if (!versionEntry.isDirectory()) continue;
            
            const skillsDir = path.join(pluginDir, versionEntry.name, 'skills');
            if (fs.existsSync(skillsDir)) {
              this.collectFromSkillDirectory(skillsDir, ToolSource.Claude, true, null, results);
            }
          }
        }
      }
    } catch (error) {
      // Ignore errors
    }
  }

  /**
   * Collect from CLI plugins (installed_plugins.json)
   */
  private collectFromCLIPlugins(results: ScannedSkillData[]): void {
    const pluginsJsonPath = path.join(this.homeDir, '.claude', 'plugins', 'installed_plugins.json');
    
    if (!fs.existsSync(pluginsJsonPath)) return;
    
    try {
      const content = fs.readFileSync(pluginsJsonPath, 'utf-8');
      const data = JSON.parse(content);
      
      if (data.plugins) {
        for (const [, installations] of Object.entries(data.plugins) as [string, unknown[]][]) {
          for (const installation of installations) {
            const inst = installation as { installPath?: string };
            if (inst.installPath) {
              const skillsDir = path.join(inst.installPath, 'skills');
              this.collectFromSkillDirectory(skillsDir, ToolSource.Claude, true, null, results);
            }
          }
        }
      }
    } catch (error) {
      console.error('[Scanner] Error parsing CLI plugins:', error);
    }
  }

  /**
   * Collect skill data from a file
   */
  private collectSkillData(
    filePath: string,
    toolSource: ToolSource,
    isDirectory: boolean,
    isGlobal: boolean,
    projectName: string | null
  ): ScannedSkillData | null {
    try {
      const content = fs.readFileSync(filePath, 'utf-8');
      const stats = fs.statSync(filePath);
      const resolvedPath = fs.realpathSync(filePath);
      
      const parsed = parseSkillFile(content, path.basename(filePath), toolSource);
      
      // Derive name
      let name = parsed.name;
      if (!name) {
        if (isDirectory) {
          name = path.basename(path.dirname(filePath));
        } else {
          name = path.basename(filePath, path.extname(filePath));
        }
      }
      
      this.progress.skillsFound++;
      
      return {
        filePath,
        resolvedPath,
        toolSource,
        isDirectory,
        isGlobal,
        projectName,
        name,
        description: parsed.description,
        content: parsed.content,
        frontmatter: parsed.frontmatter,
        modDate: stats.mtime,
        fileSize: stats.size
      };
    } catch (error) {
      console.error(`[Scanner] Error collecting skill data from ${filePath}:`, error);
      return null;
    }
  }

  /**
   * Sync scanned skills to database
   */
  async syncToDatabase(): Promise<number> {
    const results = this.scanAll();
    
    // Get all existing skills
    const existingSkills = await db.skill.findMany();
    const existingByPath = new Map(existingSkills.map(s => [s.resolvedPath, s]));
    
    // Group by resolved path
    const grouped = new Map<string, ScannedSkillData[]>();
    for (const result of results) {
      const existing = grouped.get(result.resolvedPath) || [];
      existing.push(result);
      grouped.set(result.resolvedPath, existing);
    }
    
    // Upsert skills
    let upsertCount = 0;
    for (const [resolvedPath, installations] of grouped) {
      const primary = installations[0];
      const installedPaths = [...new Set(installations.map(i => i.filePath))];
      const toolSources = [...new Set(installations.map(i => i.toolSource))];
      
      const data = {
        resolvedPath,
        filePath: primary.filePath,
        isDirectory: primary.isDirectory,
        name: primary.name,
        description: primary.description,
        content: primary.content,
        frontmatter: JSON.stringify(primary.frontmatter),
        toolSources: toolSources.join(','),
        installedPaths: JSON.stringify(installedPaths),
        isGlobal: primary.isGlobal,
        fileModifiedDate: primary.modDate,
        fileSize: primary.fileSize
      };
      
      if (existingByPath.has(resolvedPath)) {
        await db.skill.update({
          where: { resolvedPath },
          data
        });
      } else {
        await db.skill.create({ data });
        upsertCount++;
      }
    }
    
    // Remove skills that no longer exist
    const scannedPaths = new Set(grouped.keys());
    for (const skill of existingSkills) {
      if (!scannedPaths.has(skill.resolvedPath)) {
        await db.skill.delete({ where: { id: skill.id } });
      }
    }
    
    return upsertCount;
  }
}

// Singleton instance
let scannerInstance: SkillScanner | null = null;

export function getScanner(): SkillScanner {
  if (!scannerInstance) {
    scannerInstance = new SkillScanner();
  }
  return scannerInstance;
}
