import matter from 'gray-matter';
import { ToolSource } from './types';

export interface ParsedSkill {
  frontmatter: Record<string, string>;
  content: string;
  name: string;
  description: string;
}

/**
 * Parse skill content with frontmatter
 */
export function parseSkillContent(content: string, toolSource: ToolSource): ParsedSkill {
  // Use gray-matter for robust YAML frontmatter parsing
  const parsed = matter(content);
  
  const frontmatter: Record<string, string> = {};
  if (parsed.data) {
    for (const [key, value] of Object.entries(parsed.data)) {
      if (typeof value === 'string') {
        frontmatter[key] = value;
      } else if (value !== null && value !== undefined) {
        frontmatter[key] = String(value);
      }
    }
  }
  
  const name = frontmatter['name'] || '';
  const description = frontmatter['description'] || '';
  
  return {
    frontmatter,
    content: parsed.content.trim(),
    name,
    description
  };
}

/**
 * Parse heading format for skills without frontmatter
 */
export function parseHeadingFormat(content: string): ParsedSkill {
  const lines = content.split('\n');
  let name = '';
  
  for (const line of lines) {
    if (line.startsWith('# ')) {
      name = line.substring(2).trim();
      break;
    }
  }
  
  return {
    frontmatter: {},
    content: content.trim(),
    name,
    description: ''
  };
}

/**
 * Parse a skill file based on its tool source
 */
export function parseSkillFile(content: string, fileName: string, toolSource: ToolSource): ParsedSkill {
  const extension = fileName.split('.').pop()?.toLowerCase();
  
  // For MDC files (Cursor rules), use frontmatter parser
  if (extension === 'mdc') {
    return parseSkillContent(content, toolSource);
  }
  
  // For Claude, Cursor, try frontmatter first
  if (toolSource === ToolSource.Claude || 
      toolSource === ToolSource.ClaudeDesktop || 
      toolSource === ToolSource.Cursor) {
    return parseSkillContent(content, toolSource);
  }
  
  // For other tools, try frontmatter first, then heading
  const parsed = parseSkillContent(content, toolSource);
  if (parsed.name) {
    return parsed;
  }
  return parseHeadingFormat(content);
}

/**
 * Generate frontmatter for a new skill
 */
export function generateSkillFrontmatter(name: string, description: string = ''): string {
  if (description) {
    return `---
name: ${name}
description: ${description}
---

`;
  }
  return `---
name: ${name}
---

`;
}

/**
 * Serialize skill content with frontmatter
 */
export function serializeSkillContent(frontmatter: Record<string, string>, content: string): string {
  const data: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(frontmatter)) {
    data[key] = value;
  }
  
  const frontmatterStr = matter.stringify(content, data);
  return frontmatterStr;
}
